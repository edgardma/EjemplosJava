package dyd.com.pe.patrones.ejemploPatronEventDriven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploPatronEventDrivenApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploPatronEventDrivenApplication.class, args);
	}

}
