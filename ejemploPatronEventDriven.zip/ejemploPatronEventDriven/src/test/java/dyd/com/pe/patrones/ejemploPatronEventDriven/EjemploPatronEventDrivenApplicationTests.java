package dyd.com.pe.patrones.ejemploPatronEventDriven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploPatronEventDrivenApplicationTests {

	@Test
	void contextLoads() {
	}

}
